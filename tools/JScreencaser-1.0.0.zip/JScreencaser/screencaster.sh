#!/bin/sh

java -jar JScreencaster-1.0.0.jar
